import sys,time,json,math
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools/performance-probe'))
from benchmark_browser import browser,serve
root=Path.cwd();out=Path('/tmp/web-20gib-pixels');out.mkdir(exist_ok=False)
r={'status':'running','seeks':[],'source':'/tmp/mcap-single-20gib-ros2.mcap','scope':'independent predecessor pixel check; not a latency benchmark'}
try:
 with serve(root/'apps/viewer-web/dist')as url,browser('hardware',out/'chrome.log',wake_display=True,vulkan_icd='/usr/share/vulkan/icd.d/nvidia_icd.json')as(proc,page,env):
  r['environment']=env;page.call('Page.navigate',{'url':url})
  def wait(check,timeout=15):
   until=time.monotonic()+timeout
   while time.monotonic()<until:
    v=check()
    if v:return v
    time.sleep(.03)
   raise RuntimeError('functional condition timed out')
  wait(lambda:page.evaluate('document.querySelector("#bev-status")?.textContent.includes("ready")'))
  node=page.call('DOM.querySelector',{'nodeId':page.call('DOM.getDocument')['root']['nodeId'],'selector':'#mcap-file'})['nodeId'];page.call('DOM.setFileInputFiles',{'nodeId':node,'files':[r['source']]})
  wait(lambda:page.evaluate('document.querySelectorAll(".camera-card").length===4 && document.querySelector("#status").textContent.startsWith("Ready")'))
  def colors():
   return page.evaluate('["camera","camera-thumb-1","camera-thumb-2","camera-thumb-3"].map(id=>{const c=document.getElementById(id);return Array.from(c.getContext("2d").getImageData(Math.floor(c.width/2),Math.floor(c.height/2),1,1).data)})')
  for offset in [1.03,70.03,40.03,85.93,1.03]:
   seq=math.floor(offset*10);gray=32+seq%192;target=offset/86.3
   page.evaluate(f'(()=>{{const t=document.querySelector("#timeline");t.value="{target}";t.dispatchEvent(new Event("input",{{bubbles:true}}))}})()')
   def match():
    pixels=colors();cursor=page.evaluate('Number(document.querySelector("#timeline").value)')
    return {'cursor':cursor,'pixels':pixels}if abs(cursor-target)<.0002 and all(all(abs(v-gray)<=1 for v in p[:3])and p[3]==255 for p in pixels)else None
   settled=wait(match)
   deadline=time.monotonic()+.3
   while time.monotonic()<deadline:
    assert match(),'stale frame replaced restored pixels';time.sleep(.03)
   r['seeks'].append({'offset_seconds':offset,'expected_sequence':seq,'expected_gray':gray,**settled})
  r['status']='ok'
except Exception as error:r['status']='failed';r['error']=repr(error);raise
finally:(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'seeks':len(r['seeks']),'error':r.get('error')}),flush=True)
