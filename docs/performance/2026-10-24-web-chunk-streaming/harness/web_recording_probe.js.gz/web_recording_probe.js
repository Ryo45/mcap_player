// Observe production canvas contents; no app API, payload, decoder or layout patches.
(() => {
  const probe = window.recordingProbe = {phase: 'open', beats: [], changes: [], errors: []};
  addEventListener('TrunkApplicationStarted', event => { probe.memory = event.detail.wasm.memory; });
  addEventListener('error', event => probe.errors.push(event.message));
  addEventListener('unhandledrejection', event => probe.errors.push(String(event.reason)));
  setInterval(() => probe.beats.push({t: performance.now(), phase: probe.phase}), 20);
  const requestAdapter = navigator.gpu.requestAdapter.bind(navigator.gpu);
  navigator.gpu.requestAdapter = async (...args) => {
    const adapter = await requestAdapter(...args);
    if (adapter) probe.adapter = {vendor: adapter.info.vendor, architecture: adapter.info.architecture,
      device: adapter.info.device, description: adapter.info.description, fallback: adapter.info.isFallbackAdapter};
    return adapter;
  };
  const draw = CanvasRenderingContext2D.prototype.drawImage;
  const latest = new Map();
  const tiny = document.createElement('canvas'); tiny.width = 16; tiny.height = 9;
  const context = tiny.getContext('2d', {willReadFrequently: true});
  CanvasRenderingContext2D.prototype.drawImage = function(...args) {
    const result = draw.apply(this, args);
    const id = this.canvas.id;
    if (id === 'camera' || /^camera-thumb-\d+$/.test(id)) {
      context.imageSmoothingEnabled = false;
      draw.call(context, this.canvas, 0, 0, 16, 9);
      let hash = 2166136261;
      for (const byte of context.getImageData(0, 0, 16, 9).data) hash = Math.imul(hash ^ byte, 16777619);
      if (latest.get(id) !== hash) {
        latest.set(id, hash);
        probe.changes.push({id, hash: hash >>> 0, t: performance.now(), phase: probe.phase});
      }
    }
    return result;
  };
  probe.state = () => ({now: performance.now(), phase: probe.phase,
    cursor: Number(document.querySelector('#timeline')?.value),
    status: document.querySelector('#status')?.textContent,
    metrics: document.querySelector('#performance')?.textContent,
    cards: document.querySelectorAll('.camera-card').length,
    canvases: [...document.querySelectorAll('#camera, [id^="camera-thumb-"]')]
      .map(canvas => ({id: canvas.id, width: canvas.width, height: canvas.height})),
    visibility: document.visibilityState, focused: document.hasFocus(),
    changes: probe.changes.length, wasm_bytes: probe.memory?.buffer.byteLength,
    adapter: probe.adapter, errors: probe.errors});
})();
